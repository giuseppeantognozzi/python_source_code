"""
db.py  –  MySQL connection pool and all HR_Department_DB queries.
Each public function returns plain Python dicts / lists so Flask can
jsonify them directly.
"""

import logging
from contextlib import contextmanager

import mysql.connector
from mysql.connector import Error
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

#  ────────────────────────────────────────────────────────────

def get_db_connection():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='HR_Department_DB',
            user='andrea_db_user',  # Replace with your MySQL username
            password='Andrea_Secure_Pass_2026!'  # Replace with your MySQL password
        )
        return connection
    except Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None



@contextmanager
def _conn():
    """Yield a connection; commit on success, rollback on error."""
    cnx = get_db_connection()
    try:
        yield cnx
        cnx.commit()
    except Error:
        cnx.rollback()
        raise
    finally:
        cnx.close()


def _cursor(cnx, dictionary=True):
    return cnx.cursor(dictionary=dictionary)


# ══════════════════════════════════════════════════════════════════════════════
#  DEPARTMENTS
# ══════════════════════════════════════════════════════════════════════════════

def get_departments(page=1, limit=20, search="", sort="dept_id", order="ASC"):
    offset = (max(1, page) - 1) * limit
    order  = "DESC" if order.upper() == "DESC" else "ASC"
    safe_sort = sort if sort in ("dept_id", "dept_name") else "dept_id"

    with _conn() as cnx:
        cur = _cursor(cnx)

        where, params = "", []
        if search:
            where  = "WHERE dept_name LIKE %s"
            params = [f"%{search}%"]

        cur.execute(f"SELECT COUNT(*) AS total FROM Departments {where}", params)
        total = cur.fetchone()["total"]

        cur.execute(
            f"SELECT dept_id, dept_name FROM Departments "
            f"{where} ORDER BY {safe_sort} {order} "
            f"LIMIT %s OFFSET %s",
            params + [limit, offset],
        )
        rows = cur.fetchall()

    return {"data": rows, "total": total, "page": page, "limit": limit}


def create_department(dept_name: str):
    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute("INSERT INTO Departments (dept_name) VALUES (%s)", (dept_name,))
        return {"dept_id": cur.lastrowid, "dept_name": dept_name}


def update_department(dept_id: int, dept_name: str):
    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute(
            "UPDATE Departments SET dept_name=%s WHERE dept_id=%s",
            (dept_name, dept_id),
        )
        return {"affected": cur.rowcount}


def delete_department(dept_id: int):
    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute("DELETE FROM Departments WHERE dept_id=%s", (dept_id,))
        return {"affected": cur.rowcount}


# ══════════════════════════════════════════════════════════════════════════════
#  EMPLOYEES
# ══════════════════════════════════════════════════════════════════════════════

_EMP_COLS = ("emp_id", "first_name", "last_name", "email", "hire_date", "dept_id")

def get_employees(page=1, limit=20, search="", sort="emp_id", order="ASC"):
    offset    = (max(1, page) - 1) * limit
    order     = "DESC" if order.upper() == "DESC" else "ASC"
    safe_sort = sort if sort in _EMP_COLS else "emp_id"

    search_where = ""
    params: list = []
    if search:
        search_where = (
            "WHERE e.first_name LIKE %s OR e.last_name LIKE %s "
            "OR e.email LIKE %s OR d.dept_name LIKE %s"
        )
        params = [f"%{search}%"] * 4

    sql_count = f"""
        SELECT COUNT(*) AS total
        FROM Employees e
        LEFT JOIN Departments d ON e.dept_id = d.dept_id
        {search_where}
    """
    sql_rows = f"""
        SELECT e.emp_id, e.first_name, e.last_name, e.email,
               DATE_FORMAT(e.hire_date, '%Y-%m-%d') AS hire_date,
               e.dept_id, d.dept_name
        FROM Employees e
        LEFT JOIN Departments d ON e.dept_id = d.dept_id
        {search_where}
        ORDER BY e.{safe_sort} {order}
        LIMIT %s OFFSET %s
    """

    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute(sql_count, params)
        total = cur.fetchone()["total"]
        cur.execute(sql_rows, params + [limit, offset])
        rows = cur.fetchall()

    return {"data": rows, "total": total, "page": page, "limit": limit}


def create_employee(first_name, last_name, email, hire_date, dept_id):
    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute(
            "INSERT INTO Employees (first_name,last_name,email,hire_date,dept_id) "
            "VALUES (%s,%s,%s,%s,%s)",
            (first_name, last_name, email, hire_date, dept_id),
        )
        return {"emp_id": cur.lastrowid}


def update_employee(emp_id, first_name, last_name, email, hire_date, dept_id):
    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute(
            "UPDATE Employees SET first_name=%s,last_name=%s,email=%s,"
            "hire_date=%s,dept_id=%s WHERE emp_id=%s",
            (first_name, last_name, email, hire_date, dept_id, emp_id),
        )
        return {"affected": cur.rowcount}


def delete_employee(emp_id: int):
    with _conn() as cnx:
        cur = _cursor(cnx)
        # cascade delete dependent rows first
        cur.execute("DELETE FROM Skills WHERE emp_id=%s", (emp_id,))
        cur.execute("DELETE FROM Education_Certifications WHERE emp_id=%s", (emp_id,))
        cur.execute("DELETE FROM Payroll_Benefits WHERE emp_id=%s", (emp_id,))
        cur.execute("DELETE FROM Employees WHERE emp_id=%s", (emp_id,))
        return {"affected": cur.rowcount}


# ══════════════════════════════════════════════════════════════════════════════
#  PAYROLL & BENEFITS
# ══════════════════════════════════════════════════════════════════════════════

def get_payroll(page=1, limit=20, search="", sort="emp_id", order="ASC"):
    offset    = (max(1, page) - 1) * limit
    order     = "DESC" if order.upper() == "DESC" else "ASC"
    safe_sort = sort if sort in ("emp_id","job_title","salary","health_coverage_cost","first_name","last_name") else "emp_id"

    where, params = "", []
    if search:
        where  = "WHERE e.first_name LIKE %s OR e.last_name LIKE %s OR pb.job_title LIKE %s"
        params = [f"%{search}%"] * 3

    sql_count = f"""
        SELECT COUNT(*) AS total
        FROM Payroll_Benefits pb
        JOIN Employees e ON pb.emp_id = e.emp_id
        {where}
    """
    sql_rows = f"""
        SELECT pb.emp_id,
               e.first_name, e.last_name,
               pb.job_title,
               pb.salary,
               pb.health_coverage_cost
        FROM Payroll_Benefits pb
        JOIN Employees e ON pb.emp_id = e.emp_id
        {where}
        ORDER BY {safe_sort} {order}
        LIMIT %s OFFSET %s
    """

    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute(sql_count, params)
        total = cur.fetchone()["total"]
        cur.execute(sql_rows, params + [limit, offset])
        rows = cur.fetchall()
        # Convert Decimal to float for JSON
        for r in rows:
            r["salary"]               = float(r["salary"] or 0)
            r["health_coverage_cost"] = float(r["health_coverage_cost"] or 0)

    return {"data": rows, "total": total, "page": page, "limit": limit}


def upsert_payroll(emp_id, job_title, salary, health_coverage_cost):
    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute(
            """
            INSERT INTO Payroll_Benefits (emp_id, job_title, salary, health_coverage_cost)
            VALUES (%s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                job_title=%s, salary=%s, health_coverage_cost=%s
            """,
            (emp_id, job_title, salary, health_coverage_cost,
             job_title, salary, health_coverage_cost),
        )
        return {"affected": cur.rowcount}


def delete_payroll(emp_id: int):
    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute("DELETE FROM Payroll_Benefits WHERE emp_id=%s", (emp_id,))
        return {"affected": cur.rowcount}


# ══════════════════════════════════════════════════════════════════════════════
#  SKILLS
# ══════════════════════════════════════════════════════════════════════════════

def get_skills(page=1, limit=20, search="", sort="skill_id", order="ASC"):
    offset    = (max(1, page) - 1) * limit
    order     = "DESC" if order.upper() == "DESC" else "ASC"
    safe_sort = sort if sort in ("skill_id","emp_id","skill_name","first_name","last_name") else "skill_id"

    where, params = "", []
    if search:
        where  = "WHERE s.skill_name LIKE %s OR e.first_name LIKE %s OR e.last_name LIKE %s"
        params = [f"%{search}%"] * 3

    sql_count = f"""
        SELECT COUNT(*) AS total
        FROM Skills s JOIN Employees e ON s.emp_id = e.emp_id
        {where}
    """
    sql_rows = f"""
        SELECT s.skill_id, s.emp_id,
               e.first_name, e.last_name,
               s.skill_name
        FROM Skills s
        JOIN Employees e ON s.emp_id = e.emp_id
        {where}
        ORDER BY {safe_sort} {order}
        LIMIT %s OFFSET %s
    """

    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute(sql_count, params)
        total = cur.fetchone()["total"]
        cur.execute(sql_rows, params + [limit, offset])
        rows = cur.fetchall()

    return {"data": rows, "total": total, "page": page, "limit": limit}


def create_skill(emp_id, skill_name):
    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute(
            "INSERT INTO Skills (emp_id, skill_name) VALUES (%s, %s)",
            (emp_id, skill_name),
        )
        return {"skill_id": cur.lastrowid}


def update_skill(skill_id, emp_id, skill_name):
    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute(
            "UPDATE Skills SET emp_id=%s, skill_name=%s WHERE skill_id=%s",
            (emp_id, skill_name, skill_id),
        )
        return {"affected": cur.rowcount}


def delete_skill(skill_id: int):
    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute("DELETE FROM Skills WHERE skill_id=%s", (skill_id,))
        return {"affected": cur.rowcount}


# ══════════════════════════════════════════════════════════════════════════════
#  EDUCATION & CERTIFICATIONS
# ══════════════════════════════════════════════════════════════════════════════

def get_certifications(page=1, limit=20, search="", sort="cert_id", order="ASC"):
    offset    = (max(1, page) - 1) * limit
    order     = "DESC" if order.upper() == "DESC" else "ASC"
    safe_sort = sort if sort in ("cert_id","emp_id","certification_name","first_name","last_name") else "cert_id"

    where, params = "", []
    if search:
        where  = "WHERE ec.certification_name LIKE %s OR e.first_name LIKE %s OR e.last_name LIKE %s"
        params = [f"%{search}%"] * 3

    sql_count = f"""
        SELECT COUNT(*) AS total
        FROM Education_Certifications ec
        JOIN Employees e ON ec.emp_id = e.emp_id
        {where}
    """
    sql_rows = f"""
        SELECT ec.cert_id, ec.emp_id,
               e.first_name, e.last_name,
               ec.certification_name
        FROM Education_Certifications ec
        JOIN Employees e ON ec.emp_id = e.emp_id
        {where}
        ORDER BY {safe_sort} {order}
        LIMIT %s OFFSET %s
    """

    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute(sql_count, params)
        total = cur.fetchone()["total"]
        cur.execute(sql_rows, params + [limit, offset])
        rows = cur.fetchall()

    return {"data": rows, "total": total, "page": page, "limit": limit}


def create_certification(emp_id, certification_name):
    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute(
            "INSERT INTO Education_Certifications (emp_id, certification_name) VALUES (%s, %s)",
            (emp_id, certification_name),
        )
        return {"cert_id": cur.lastrowid}


def update_certification(cert_id, emp_id, certification_name):
    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute(
            "UPDATE Education_Certifications SET emp_id=%s, certification_name=%s "
            "WHERE cert_id=%s",
            (emp_id, certification_name, cert_id),
        )
        return {"affected": cur.rowcount}


def delete_certification(cert_id: int):
    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute(
            "DELETE FROM Education_Certifications WHERE cert_id=%s", (cert_id,)
        )
        return {"affected": cur.rowcount}


# ══════════════════════════════════════════════════════════════════════════════
#  HELPER: dropdown lists for forms
# ══════════════════════════════════════════════════════════════════════════════

def get_all_departments():
    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute("SELECT dept_id, dept_name FROM Departments ORDER BY dept_name")
        return cur.fetchall()


def get_all_employees_lookup():
    with _conn() as cnx:
        cur = _cursor(cnx)
        cur.execute(
            "SELECT emp_id, CONCAT(first_name,' ',last_name) AS full_name "
            "FROM Employees ORDER BY last_name, first_name"
        )
        return cur.fetchall()
