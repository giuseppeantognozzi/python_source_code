"""
app.py  –  Flask REST API + HTML host for HR_Department_DB PyScript app.

Endpoints
─────────
GET  /                                    → main HTML page
GET  /api/departments                     → paginated list
POST /api/departments                     → create
PUT  /api/departments/<id>               → update
DEL  /api/departments/<id>               → delete

GET  /api/employees                       → paginated list
POST /api/employees                       → create
PUT  /api/employees/<id>                 → update
DEL  /api/employees/<id>                 → delete

GET  /api/payroll                         → paginated list
POST /api/payroll                         → upsert
DEL  /api/payroll/<emp_id>               → delete

GET  /api/skills                          → paginated list
POST /api/skills                          → create
PUT  /api/skills/<id>                    → update
DEL  /api/skills/<id>                    → delete

GET  /api/certifications                  → paginated list
POST /api/certifications                  → create
PUT  /api/certifications/<id>            → update
DEL  /api/certifications/<id>            → delete

GET  /api/lookup/departments              → [{dept_id, dept_name}, …]
GET  /api/lookup/employees               → [{emp_id, full_name}, …]
"""

from flask import Flask, jsonify, request, send_from_directory, abort
from flask_cors import CORS
from mysql.connector import Error
import logging
import db

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(name)s  %(message)s")
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)


# ── Helpers ────────────────────────────────────────────────────────────────────

def _qp(key, default, cast=str):
    """Pull a query parameter with a default and type cast."""
    try:
        return cast(request.args.get(key, default))
    except (ValueError, TypeError):
        return cast(default)


def _json_error(msg: str, code: int = 400):
    return jsonify({"error": msg}), code


def _handle(fn, *args, **kwargs):
    """Wrap a db call; return 500 on MySQL errors."""
    try:
        result = fn(*args, **kwargs)
        return jsonify(result)
    except Error as e:
        logger.error(e)
        return _json_error(str(e), 500)
    except Exception as e:
        logger.exception(e)
        return _json_error("Internal server error", 500)


# ── Main page ──────────────────────────────────────────────────────────────────
# IMPORTANT: use send_from_directory (not render_template) so Jinja2 never
# parses index.html.  The PyScript code contains {{ }} and {expr} blocks that
# Jinja2 mistakes for template tags, causing TemplateSyntaxError.

@app.route("/")
def index():
    return send_from_directory("static", "index.html")


# ── Departments ────────────────────────────────────────────────────────────────

@app.route("/api/departments", methods=["GET"])
def api_get_departments():
    return _handle(
        db.get_departments,
        page   =_qp("page",   1,    int),
        limit  =_qp("limit",  20,   int),
        search =_qp("search", ""),
        sort   =_qp("sort",   "dept_id"),
        order  =_qp("order",  "ASC"),
    )


@app.route("/api/departments", methods=["POST"])
def api_create_department():
    body = request.get_json(silent=True) or {}
    name = (body.get("dept_name") or "").strip()
    if not name:
        return _json_error("dept_name is required")
    return _handle(db.create_department, name), 201


@app.route("/api/departments/<int:dept_id>", methods=["PUT"])
def api_update_department(dept_id):
    body = request.get_json(silent=True) or {}
    name = (body.get("dept_name") or "").strip()
    if not name:
        return _json_error("dept_name is required")
    return _handle(db.update_department, dept_id, name)


@app.route("/api/departments/<int:dept_id>", methods=["DELETE"])
def api_delete_department(dept_id):
    return _handle(db.delete_department, dept_id)


# ── Employees ──────────────────────────────────────────────────────────────────

@app.route("/api/employees", methods=["GET"])
def api_get_employees():
    return _handle(
        db.get_employees,
        page  =_qp("page",   1,   int),
        limit =_qp("limit",  20,  int),
        search=_qp("search", ""),
        sort  =_qp("sort",   "emp_id"),
        order =_qp("order",  "ASC"),
    )


@app.route("/api/employees", methods=["POST"])
def api_create_employee():
    b = request.get_json(silent=True) or {}
    required = ("first_name", "last_name", "email", "hire_date", "dept_id")
    missing  = [f for f in required if not b.get(f)]
    if missing:
        return _json_error(f"Missing fields: {', '.join(missing)}")
    return _handle(
        db.create_employee,
        b["first_name"], b["last_name"], b["email"],
        b["hire_date"], int(b["dept_id"]),
    ), 201


@app.route("/api/employees/<int:emp_id>", methods=["PUT"])
def api_update_employee(emp_id):
    b = request.get_json(silent=True) or {}
    required = ("first_name", "last_name", "email", "hire_date", "dept_id")
    missing  = [f for f in required if not b.get(f)]
    if missing:
        return _json_error(f"Missing fields: {', '.join(missing)}")
    return _handle(
        db.update_employee,
        emp_id,
        b["first_name"], b["last_name"], b["email"],
        b["hire_date"], int(b["dept_id"]),
    )


@app.route("/api/employees/<int:emp_id>", methods=["DELETE"])
def api_delete_employee(emp_id):
    return _handle(db.delete_employee, emp_id)


# ── Payroll & Benefits ─────────────────────────────────────────────────────────

@app.route("/api/payroll", methods=["GET"])
def api_get_payroll():
    return _handle(
        db.get_payroll,
        page  =_qp("page",   1,   int),
        limit =_qp("limit",  20,  int),
        search=_qp("search", ""),
        sort  =_qp("sort",   "emp_id"),
        order =_qp("order",  "ASC"),
    )


@app.route("/api/payroll", methods=["POST"])
def api_upsert_payroll():
    b = request.get_json(silent=True) or {}
    required = ("emp_id", "job_title", "salary", "health_coverage_cost")
    missing  = [f for f in required if b.get(f) is None]
    if missing:
        return _json_error(f"Missing fields: {', '.join(missing)}")
    return _handle(
        db.upsert_payroll,
        int(b["emp_id"]), b["job_title"],
        float(b["salary"]), float(b["health_coverage_cost"]),
    ), 201


@app.route("/api/payroll/<int:emp_id>", methods=["DELETE"])
def api_delete_payroll(emp_id):
    return _handle(db.delete_payroll, emp_id)


# ── Skills ─────────────────────────────────────────────────────────────────────

@app.route("/api/skills", methods=["GET"])
def api_get_skills():
    return _handle(
        db.get_skills,
        page  =_qp("page",   1,   int),
        limit =_qp("limit",  20,  int),
        search=_qp("search", ""),
        sort  =_qp("sort",   "skill_id"),
        order =_qp("order",  "ASC"),
    )


@app.route("/api/skills", methods=["POST"])
def api_create_skill():
    b = request.get_json(silent=True) or {}
    if not b.get("emp_id") or not b.get("skill_name"):
        return _json_error("emp_id and skill_name are required")
    return _handle(db.create_skill, int(b["emp_id"]), b["skill_name"].strip()), 201


@app.route("/api/skills/<int:skill_id>", methods=["PUT"])
def api_update_skill(skill_id):
    b = request.get_json(silent=True) or {}
    if not b.get("emp_id") or not b.get("skill_name"):
        return _json_error("emp_id and skill_name are required")
    return _handle(db.update_skill, skill_id, int(b["emp_id"]), b["skill_name"].strip())


@app.route("/api/skills/<int:skill_id>", methods=["DELETE"])
def api_delete_skill(skill_id):
    return _handle(db.delete_skill, skill_id)


# ── Education & Certifications ────────────────────────────────────────────────

@app.route("/api/certifications", methods=["GET"])
def api_get_certifications():
    return _handle(
        db.get_certifications,
        page  =_qp("page",   1,   int),
        limit =_qp("limit",  20,  int),
        search=_qp("search", ""),
        sort  =_qp("sort",   "cert_id"),
        order =_qp("order",  "ASC"),
    )


@app.route("/api/certifications", methods=["POST"])
def api_create_certification():
    b = request.get_json(silent=True) or {}
    if not b.get("emp_id") or not b.get("certification_name"):
        return _json_error("emp_id and certification_name are required")
    return _handle(
        db.create_certification,
        int(b["emp_id"]), b["certification_name"].strip(),
    ), 201


@app.route("/api/certifications/<int:cert_id>", methods=["PUT"])
def api_update_certification(cert_id):
    b = request.get_json(silent=True) or {}
    if not b.get("emp_id") or not b.get("certification_name"):
        return _json_error("emp_id and certification_name are required")
    return _handle(
        db.update_certification,
        cert_id, int(b["emp_id"]), b["certification_name"].strip(),
    )


@app.route("/api/certifications/<int:cert_id>", methods=["DELETE"])
def api_delete_certification(cert_id):
    return _handle(db.delete_certification, cert_id)


# ── Lookup dropdowns ──────────────────────────────────────────────────────────

@app.route("/api/lookup/departments")
def api_lookup_departments():
    return _handle(db.get_all_departments)


@app.route("/api/lookup/employees")
def api_lookup_employees():
    return _handle(db.get_all_employees_lookup)


# ── Run ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
